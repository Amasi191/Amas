
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'tracking_screen.dart';
import 'package:url_launcher/url_launcher.dart';

class CheckoutScreen extends StatelessWidget {
  final List<Map> cart;

  CheckoutScreen({required this.cart});

  double get total => cart.fold(0, (sum, item) => sum + item['price']);

  void confirmOrder(BuildContext context) async {
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Order placed! Your location: \${position.latitude}, \${position.longitude}'),
    ));
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TrackingScreen(userLat: position.latitude, userLng: position.longitude),
      ),
    );
  }

  void launchPaymentGateway(String method) async {
    String url = "https://paymentgateway.com/pay?method=\$method&amount=\${total.toStringAsFixed(2)}";
    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Checkout")),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: cart.map((item) => ListTile(
                title: Text(item['name']),
                trailing: Text("\$${item['price']}"),
              )).toList(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text("Total: \$${total.toStringAsFixed(2)}", style: TextStyle(fontSize: 18)),
                ElevatedButton(onPressed: () => confirmOrder(context), child: Text("Pay via Airtel Money")),
                ElevatedButton(onPressed: () => launchPaymentGateway("mpesa"), child: Text("Pay via M-Pesa")),
                ElevatedButton(onPressed: () => launchPaymentGateway("paypal"), child: Text("Pay via PayPal")),
                ElevatedButton(onPressed: () => launchPaymentGateway("visa"), child: Text("Pay via Visa/Mastercard")),
              ],
            ),
          )
        ],
      ),
    );
  }
}

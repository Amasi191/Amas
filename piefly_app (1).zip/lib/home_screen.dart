
import 'package:flutter/material.dart';
import 'checkout_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Map> foods = [
    {"name": "Pepperoni Pizza", "price": 8.99, "image": "https://example.com/pizza.jpg"},
    {"name": "Cheese Burger", "price": 6.50, "image": "https://example.com/burger.jpg"},
  ];

  final List<Map> drinks = [
    {"name": "Coca Cola", "price": 1.99, "image": "https://example.com/coke.jpg"},
    {"name": "Orange Juice", "price": 2.50, "image": "https://example.com/juice.jpg"},
  ];

  List<Map> cart = [];

  void addToCart(Map item) {
    setState(() {
      cart.add(item);
    });
  }

  void goToCheckout() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CheckoutScreen(cart: cart)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Piefly Menu"),
        actions: [
          IconButton(icon: Icon(Icons.shopping_cart), onPressed: goToCheckout)
        ],
      ),
      body: ListView(
        children: [
          Padding(padding: EdgeInsets.all(8), child: Text("Food", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          ...foods.map((item) => Card(
            child: ListTile(
              leading: Image.network(item['image'], width: 50, height: 50, fit: BoxFit.cover),
              title: Text(item['name']),
              trailing: Text("\$${item['price']}"),
              onTap: () => addToCart(item),
            ),
          )),
          Padding(padding: EdgeInsets.all(8), child: Text("Drinks", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          ...drinks.map((item) => Card(
            child: ListTile(
              leading: Image.network(item['image'], width: 50, height: 50, fit: BoxFit.cover),
              title: Text(item['name']),
              trailing: Text("\$${item['price']}"),
              onTap: () => addToCart(item),
            ),
          )),
        ],
      ),
    );
  }
}

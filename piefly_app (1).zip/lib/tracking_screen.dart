
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class TrackingScreen extends StatelessWidget {
  final double userLat;
  final double userLng;
  final double deliveryLat = -6.815;
  final double deliveryLng = 39.279;

  TrackingScreen({required this.userLat, required this.userLng});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Live Tracking")),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(userLat, userLng),
          zoom: 14,
        ),
        markers: {
          Marker(markerId: MarkerId("user"), position: LatLng(userLat, userLng), infoWindow: InfoWindow(title: "Your Location")),
          Marker(markerId: MarkerId("delivery"), position: LatLng(deliveryLat, deliveryLng), infoWindow: InfoWindow(title: "Delivery Guy")),
        },
      ),
    );
  }
}
